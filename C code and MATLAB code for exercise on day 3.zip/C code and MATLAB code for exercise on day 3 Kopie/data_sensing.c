# include <stdio.h>
# include <sys/time.h>
/*********************************************************************/
// Task 1
//Please include necessary .h file for the program 




/*********************************************************************/

int main(){
	

	// for recording time for periodic task
	struct timeval t_start;
	struct timeval t_end;
	float  start, end, t_du,delay;
	float  period = 20000;
	float  delay_con = 70;
	
	/*********************************************************************/
	// Task 2
	// Please fill in the address of the i2c device, i.e., 0x??, pinBase and the pin you use for measurement
	int i2cAddr = ???;
	int pinBase = ???;
	int pinused = ???;
	/*********************************************************************/
	
	/*********************************************************************/
	// Task 3
	//Please define variables for your program 




	/*********************************************************************/
	
	/*********************************************************************/
	// Task 4
	//Please put your code for initializing wiringPi and setting up ads1115




	/*********************************************************************/
	
	while(1){
		// obtain the starting time point
		gettimeofday(&t_start, NULL);
		
		/*********************************************************************/
		// Task 5
		//Please write your codes for measurement and data recording
 
 
 
 
		
		/*********************************************************************/	
		
		// calculate and setting time delay
		gettimeofday(&t_end, NULL);
		delay = period - ((t_end.tv_sec - t_start.tv_sec)*1000000 + (t_end.tv_usec - t_start.tv_usec))-delay_con;
		if (delay <0)
		{
			delay = 0;
		}
		delayMicroseconds(delay);
	}
	return 0;	
}
